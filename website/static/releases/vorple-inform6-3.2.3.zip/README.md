# Inform 6 extensions for Vorple

This repository contains the official Inform 6 extensions for Vorple.

The documentation for how to use the extensions as a game author is at [vorple-if.com](https://vorple-if.com).


## Unit tests

See [this document](tests/README.md) for information on how to run the unit tests.